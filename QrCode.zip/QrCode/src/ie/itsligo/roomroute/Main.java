package ie.itsligo.roomroute;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JTextField;

import com.google.zxing.EncodeHintType;
import com.google.zxing.NotFoundException;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class Main {

		static JTextField textField = null;
		static String qrCodeData ;
		static String filePath ;
		
		static QR qr;
		static Room room = new Room();
		static Time time = new Time();
		static Directions directions = new Directions();

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public static void main(String[] args) throws WriterException, IOException, NotFoundException {
			//Initial hardcoded data for test program 
			qrCodeData = "Day: Tuesday\nTime: 13:00 to 15:00\nSubject: Software Engineering\nRoom: Z2004";
			filePath = "myQRCode5.png";
			
			qr = new QR(qrCodeData, filePath);
			
			Map hintMap = new HashMap();
			hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

			// create the QR barcode
			qr.createQRCode(qrCodeData, filePath, hintMap, 200, 200);
			System.out.println("QR Code image created successfully!");

			// read the barcode
			String QRdata = qr.readUserQRCode();
			System.out.println("The barcode reads : " + QRdata);

			//checking the time
			String theTime = time.get(QRdata);
			System.out.println("Your are " + theTime);
			
			// Find the room
			String theRoom = room.get(QRdata);
			System.out.println("The room is " + theRoom);
			
			// get directions
			if (directions.validate(theRoom) == false) {
				System.out.println("The directions to this room are unknown");
			}
			else {
				System.out.println("DIRECTIONS:");
				if (directions.toBuilding()=="Sorry, that building in not recognised") {
					System.out.println(directions.toBuilding());
					directions.playit(directions.soundPlay1);
				}else {
					System.out.println(directions.toBuilding());
					if(directions.toFloor()=="Sorry, floor " + directions.getFloor() + " is not recognised") {
						System.out.println(directions.toFloor());
						directions.playit(directions.soundPlay2);
					}else {
						System.out.println(directions.toFloor());
						System.out.println(directions.toLocation());
						directions.playit(directions.soundPlay1);
						directions.playit(directions.soundPlay2);
						directions.playit(directions.soundPlay3);
					}
				}
			
			
			}
		}

}
