package ie.itsligo.roomroute;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;
import java.util.Date;

public class Time {
    private String time;
    private String startingHour;
    private String startingMin;
    private Integer intStartingMin;

    public Time() {

    }

    public String get(String data)
    {

        // Here you write the code to parse the data string and extract the hour

        StringTokenizer st = new StringTokenizer(data);
        StringTokenizer st1 = new StringTokenizer(data);

        while (st.hasMoreTokens()) {
            if(st.nextToken().startsWith("Time")){
                startingHour = st.nextToken(":").trim();
                
            }

        }

        while (st1.hasMoreTokens()) {
            if(st1.nextToken().startsWith("Time")){
                startingMin = st1.nextToken("to").trim();
                char charsMin1 = startingMin.charAt ( 3 );
                char charsMin2 = startingMin.charAt ( 4 );
                String startingMin1 = "";
                startingMin1+=charsMin1;
                //startingMin1+=charsMin2;
                intStartingMin = Integer.parseInt(startingMin1);
                
            }

        }

        //setting the new format for time
        SimpleDateFormat ftHour = new SimpleDateFormat ( "HH" );
        SimpleDateFormat ftMin = new SimpleDateFormat ( "mm" );
        Date date = new Date();
        //putting current Hour into String with the good format into variable
        String currentHour = String.format(ftHour.format ( date ) );
        String currentMin = String.format(ftMin.format ( date ) );

        //converting current hour and starting hour into a int
        Integer intCurrentHour = Integer.parseInt(currentHour);
        Integer intStartingHour = Integer.parseInt(startingHour);
        Integer intCurrentMin = Integer.parseInt(currentMin);

        if (intCurrentHour>intStartingHour) {time = "late >1h";}
        else if (intCurrentHour==intStartingHour) {
            if (intCurrentMin > intStartingMin) {
                time = "late <1h";
            } else {
                time = "on time <1h";
            }
        }
        else {time = "on time";}

        return(time);
    }

}
